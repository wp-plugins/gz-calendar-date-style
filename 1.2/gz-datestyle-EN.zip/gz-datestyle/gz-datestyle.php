<?php
/*
Plugin Name: GZ Calendar Date Style
Plugin URI: http://www.giallozafferano.it/gialloblog/index.php/gz-calendar-date-style/
Description: Displays a Calendar Date Style of your WordPress blog's post/page.
Version: 1.2
Author: Julien Giusta
Author URI: http://www.giallozafferano.it
*/


/*  
	Copyright 2007  Julien Giusta  (email : splirus@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

*/


### Create Text Domain For Translations
load_plugin_textdomain('GZ Date Style', 'wp-content/plugins/gz-datestyle');

function addCssDateStyle() {
?>
<link rel="stylesheet" href="<?=get_settings('siteurl')?>/wp-content/plugins/gz-datestyle/calendar.css" type="text/css" media="screen" />
<!--[if IE 7 ]><link rel="stylesheet" href="<?=get_settings('siteurl')?>/wp-content/plugins/thickbox/jquery.tabs-ie.css" type="text/css" media="screen" /><![endif]-->
<?php
}

add_action('wp_head', 'addCssDateStyle');

### Function: Display Calendar
function draw_calendar() {
	$output = '';
	
	//Define Style for Calendar
	$output .= "<div class=\"miniCalendar\">\n
						<div align=\"center\" class=\"monthYear\">".get_the_time('M')."&nbsp;&nbsp;".get_the_time('y')."</div>\n
						<div class=\"paper\">\n
							<div align=\"center\" class=\"theDay\">".get_the_time('j')."</div>\n
						</div>\n
					</div>\n";
	print $output;
}

function gzdate_footer(){
	echo "<div align='center'><a href='http://www.giallozafferano.it/gialloblog/index.php/gz-calendar-date-style/' title='GZ Date Style Calendar'>GZ Calendar Date Style</a> by <a href='http://www.giallozafferano.it' title='Homepage GialloZafferano.it'>GialloZafferano.it</a></div>";
}
// Powered code in the footer
add_action( 'wp_footer', 'gzdate_footer', 10 );

?>